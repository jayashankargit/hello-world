var app=angular.module('myApp', []);
app.controller('namesCtrl', function($scope) {
	$scope.myFunction=function(endDate){
		if(endDate!=undefined){
			alert(JSON.stringify(endDate));
		}
	}
	$scope.fun=function(){
		alert();
	}
	$scope.employeeFocusOutFunction = function(){
		//to do a call to java to fetch datas from db
		$.ajax({
			url:'LeaveApplicationForm',
			data:{employeeId:$scope.employeeId,name:'abc'},
			type:'get',
			cache:false,
			success:function(data,status,xhr){
				var employeeId=xhr.getResponseHeader('employeeId');
				var name=xhr.getResponseHeader('name');
				console.log(employeeId);
				console.log(name);
			},
			error:function(){
				alert('error');
			}
		});
	}
	$scope.submitFunction = function(){
		var oneDayLeave;
		var halfDay;
		console.log($scope.oneDayLeave);
		if($scope.oneDayLeave==undefined){
			oneDayLeave=0;
		} else {
			oneDayLeave=1;
		}
		if($scope.halfDay==undefined){
			halfDay=0;
		} else {
			halfDay=1;
		}
		//to send a mail to ll
		$.ajax({
			url:'LeaveApplicationForm',
			data:{name:'abc',
				methodName:'submitFunction',
				oneDayLeave:oneDayLeave,
				halfDay:halfDay,
				leaveType:$scope.item,
				startDate:$scope.startDate,
				endDate:$scope.endDate,
				leaveDays:$scope.leaveDays
				},
			type:'get',
			cache:false,
			success:function(data,status,xhr){
				var name1=xhr.getResponseHeader('name');
				alert(name1);
			},
			error:function(){
				alert('error');
			}
		});
		alert();
	}
	/**
	 * to calculate leave days
	 * to do minus the leave days.
	 */
	$scope.leaveDayCalculationFunction = function(){
		var x=new Date($scope.startDate);
		var array;
		if($scope.startDate !== undefined && $scope.startDate !== null
				&& $scope.endDate !== undefined && $scope.endDate !== null){
			var startDateValues = (JSON.stringify($scope.startDate)).split('-');
			var endDateValues = (JSON.stringify($scope.endDate)).split('-');
			var selectedEndYear = parseInt((!endDateValues[0])?'':endDateValues[0].replace('"',''));
			var selectedEndMonth = parseInt(endDateValues[1]);
			var selectedEndDate = parseInt(endDateValues[2]);
			var selectedStartYear = parseInt((!startDateValues[0])?'':startDateValues[0].replace('"',''));
			var selectedStartMonth = parseInt(startDateValues[1]);
			var selectedStartDate = parseInt(startDateValues[2]);
			var calculatedYearValue = selectedEndYear - selectedStartYear;
			var incrementer;
			var calculatedDateValue;
			var calculatedMonthValue;
			var addedDays = 0;
			var addedDateValue = 0;
			if(calculatedYearValue != 0 && !isNaN(calculatedYearValue)){
				addedMonthValue = (calculatedYearValue*12);
				calculatedMonthValue = (selectedEndMonth+addedMonthValue)-selectedStartMonth;
			} else{
				calculatedMonthValue = selectedEndMonth - selectedStartMonth;
			}
			for(incrementer = 0; incrementer < calculatedMonthValue; incrementer++){
				if(calculatedMonthValue != 0){
					if(selectedStartMonth <= 6){
						if((selectedStartMonth % 2 == 0)&&!(selectedStartMonth == 2)){
						addedDays = addedDays + 30;
						} else if(selectedStartMonth == 2){
							if(selectedStartYear % 4 == 0 && selectedStartYear % 100 == 0 && selectedStartYear % 400 == 0){
								addedDays = addedDays + 29;
							} else {
								addedDays = addedDays + 28;
							}
							} else {
							addedDays = addedDays + 31;
						}
				   } else {
							if(selectedStartMonth % 2 == 0 || selectedStartMonth == 7){
							addedDays = addedDays + 31;
							} else {
							addedDays = addedDays + 30;
							}
						}
				} else {
					 calculatedDateValue = selectedEndDate - selectedStartDate;	
					}
					addedDateValue = addedDays;
					if(selectedStartMonth == 12){
						selectedStartMonth = 1;
					} else {
						selectedStartMonth++;
						}
					}
			$scope.calculatedDateValue=(selectedEndDate+addedDateValue) - selectedStartDate;
		}
	}
	$scope.myData=[{name:'jay', age:21},
	               {name:'hari', age:21}
	];
	$scope.gridOptions={data:'myData'};
});