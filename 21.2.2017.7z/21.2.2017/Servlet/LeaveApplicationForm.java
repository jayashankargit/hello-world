package Servlet;

import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.text.DateFormatter;

/**
 * Servlet implementation class LeaveApplicationForm
 */
public class LeaveApplicationForm extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LeaveApplicationForm() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String methodName = request.getParameter("methodName");
		switch(methodName){
		case "submitFunction":
			String oneDayLeave = request.getParameter("oneDayLeave");
			String halfDay = request.getParameter("halfDay");
			String leaveType = request.getParameter("leaveType");
			String startDate = request.getParameter("startDate");
			String endDate = request.getParameter("endDate");
			String leaveDays = request.getParameter("leaveDays"); 
			Date myDate = new Date(startDate);
			//date format is changed as per db saving
			System.out.println(new SimpleDateFormat("MM/dd/yyyy").format(myDate));
			System.out.println(new SimpleDateFormat("yyyy/MM/dd").format(myDate));
			System.out.println(startDate);
		}
		String employeeId=request.getParameter("employeeId");
		String name=request.getParameter("name");
		response.addHeader("employeeId", employeeId);
		response.addHeader("name", name);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}
}