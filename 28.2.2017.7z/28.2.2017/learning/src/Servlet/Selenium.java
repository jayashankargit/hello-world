package Servlet;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Selenium {
	public static void main(String args[]){
		WebDriver driver = new ChromeDriver();
		String baseUrl = "http://www.google.co.in";
//		String aa =  driver.getTitle();
//	     System.out.println(aa);
	      driver.get(baseUrl);
	      String a = driver.getCurrentUrl();
	      System.out.println(a);
	      driver.manage().window().maximize();
	      driver.findElement(By.id("cpar1")).sendKeys("10");
	}
}