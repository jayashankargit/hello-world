var app=angular.module('myApp', []);
app.controller('login', function($scope) {
	$scope.loginFunction = function(){
		var mailId=$scope.mailId;
		var password=$scope.password;
		if(mailId!=null&&mailId!=''){
			if(password!=null&&password!=''){
				$.ajax({
					url:'LeaveApplicationLoginForm',
					data:{mailId:mailId,password:password},
					type:'post',
					cache:false,
					success:function(data,status,response){
						//to get the value, response as response from java
					},
					error:function(){

					}
				});
			} else {
				alert('password is empty');
			}
		} else {
			alert('login_id and password is empty');
		}
	}
});
