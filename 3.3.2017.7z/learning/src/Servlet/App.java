package Servlet;

import java.util.HashMap;
import java.util.Map;

import org.json.JSONException;
import org.json.JSONObject;

//import Tool.ToolPro.JSONObject;

public class App
{
	public static void main(String args[]) throws JSONException{
		App object = new App();
		String jsonString = object.callMethod();
		System.out.print(jsonString);
	}
	public String callMethod() throws JSONException{
		JSONObject obj = new JSONObject();
		Map<String, String> mapData = new HashMap<String, String>();
		mapData.put("key", "value");
		obj.put("mapData", mapData);
        obj.put("name", "foo");
        obj.put("num", new Integer(100));
        obj.put("balance", new Double(1000.21));
        obj.put("is_vip", new Boolean(true));

        System.out.print(obj);
		return obj.toString();
	}
}