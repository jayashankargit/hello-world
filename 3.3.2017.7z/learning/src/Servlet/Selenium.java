package Servlet;

import java.awt.GridLayout;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;


public class Selenium {
	private static JFrame mainFrame;
	private static JPanel controlPanel;
	private static JPanel getIdPanel;
	private static JPanel okPanel;
	private static JLabel UserLabel;
	private static JLabel UserName;
	private static JLabel Passwordlabel;
	private static JLabel featureIDLabel;
	private static JTextField FeatureIDText;
	private static JTextField userIdText;
	private static TextField passwordText;
	private static JButton button;
	private static JButton cancelbutton;
	private static JCheckBox checkBox;
	private static File file;
	private static String userId;
	private static String password;
	private static String featureId;
	List<String> List = new ArrayList<String>();

	public static void main(String[] args) throws IOException{
		GetGui();
	}
	public static void  GetGui() throws IOException {
		file = new File("D:/credentials.txt");
		String getread;
		mainFrame = new JFrame("Redmine");
		mainFrame.setSize(300,135);
		mainFrame.setLayout(new GridLayout(3, 1));
		mainFrame.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent windowEvent){
				System.exit(0);
			}        
		});  
		UserLabel = new JLabel("UserId      ");  
		userIdText = new JTextField(10);
		Passwordlabel = new JLabel("Password");  
		passwordText = new TextField(13);
		passwordText.setEchoChar('*');
		featureIDLabel = new JLabel("Issue_ID");  
		button = new JButton("ok");
		cancelbutton = new JButton("newuser");
		button.setSize(40, 80);
		FeatureIDText = new JTextField(10);
		controlPanel = new JPanel();
		getIdPanel = new JPanel();
		okPanel = new JPanel();
		checkBox = new JCheckBox("save credentials");
		getIdPanel.add(UserLabel);
		getIdPanel.add(userIdText);
		getIdPanel.add(Passwordlabel);
		getIdPanel.add(passwordText);
		controlPanel.add(featureIDLabel);
		controlPanel.add(FeatureIDText);
		okPanel.add(button);
		final List<String> List = new ArrayList<String>();
		if(!file.exists()){
			mainFrame.setSize(250,190);
			okPanel.add(checkBox);
			mainFrame.add(getIdPanel);
		}else{
			FileReader reader = new FileReader(file.getAbsoluteFile());
			BufferedReader bufread = new BufferedReader(reader);
			while((getread = bufread.readLine()) != null){
				List.add(getread);
			}
			userId = List.get(0);
			password = List.get(1);
			UserName = new JLabel("("+userId+")");
			controlPanel.add(UserName);
			okPanel.add(cancelbutton);
			bufread.close();
		}
		mainFrame.add(controlPanel);
		mainFrame.add(okPanel);
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				featureId = FeatureIDText.getText();
				if(!file.exists()){
					userId = userIdText.getText();
					password = passwordText.getText();
				}
				runRedmine();
			}
		});
		cancelbutton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(file.exists()){
				file.delete();
				mainFrame.setVisible(false);
				try {
					GetGui();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				}  
			}
		});
		mainFrame.setLocationRelativeTo(null);
		mainFrame.setVisible(true);
	}
	public static void runRedmine()  {
		WebDriver driver = new FirefoxDriver();
		try{
		driver.navigate().to("http://192.168.41.237/redmine/login");
		driver.findElement(By.xpath("//*[@id='username']")).click();
		driver.findElement(By.id("username")).sendKeys(userId);
		driver.findElement(By.id("password")).sendKeys(password);
		driver.findElement(By.name("login")).click();
		driver.findElement(By.xpath("//*[@class='my-page']")).click();
		String today= driver.findElement(By.xpath("/html/body/div/div/div[1]/div[3]/div[2]/div[2]/div[1]/table/tbody/tr[1]/td[1]/strong")).getText();
		String hour =driver.findElement(By.xpath("/html/body/div/div/div[1]/div[3]/div[2]/div[2]/div[1]/table/tbody/tr[1]/td[3]/em/span[1]")).getText();
		String min =driver.findElement(By.xpath("/html/body/div/div/div[1]/div[3]/div[2]/div[2]/div[1]/table/tbody/tr[1]/td[3]/em/span[2]")).getText();
		System.out.println(today);
		if(today.equals("Today")){
			JOptionPane.showMessageDialog(mainFrame,
					"Today already you have given log time of "+hour+min,
					"A plain message",
					JOptionPane.PLAIN_MESSAGE);
			driver.close();
			System.exit(0);
		}else{
			driver.navigate().to("http://192.168.41.237/redmine/projects/cjk-kyoyo/time_entries/new");
			driver.findElement(By.id("time_entry_issue_id")).sendKeys(featureId);
			driver.findElement(By.id("time_entry_hours")).sendKeys("7.50");
			driver.findElement(By.id("time_entry_activity_id")).sendKeys("Development");
			driver.findElement(By.name("continue")).click();
			driver.findElement(By.id("time_entry_issue_id")).clear();
			driver.findElement(By.id("time_entry_issue_id")).sendKeys("130419");
			driver.findElement(By.id("time_entry_hours")).clear();
			driver.findElement(By.id("time_entry_hours")).sendKeys(".50");
			driver.findElement(By.id("time_entry_activity_id")).sendKeys("Group Meeting");
			driver.findElement(By.name("commit")).click();
			driver.findElement(By.xpath("//*[@class='my-page']")).click();
			if(checkBox.isSelected()){
				if(!file.exists()){
					file.createNewFile();
				}
				FileWriter writer = new FileWriter(file.getAbsoluteFile());
				BufferedWriter bufwriter = new BufferedWriter(writer);
				bufwriter.write(userId);
				bufwriter.newLine();
				bufwriter.write(password);
				bufwriter.close();
			}
			JOptionPane.showMessageDialog(mainFrame,
					"Logged successfully.",
					"A plain message",
					JOptionPane.PLAIN_MESSAGE);
			driver.close();
			System.exit(0);
		}
		}catch(Exception e){
				JOptionPane.showMessageDialog(mainFrame,
						"Failed try again.",
						"A plain message",
						JOptionPane.WARNING_MESSAGE);
				driver.close();
			}
		};
	}
