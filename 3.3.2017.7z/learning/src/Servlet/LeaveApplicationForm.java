package Servlet;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//import org.json.JSONException;
//import org.json.JSONObject;

/**
 * Servlet implementation class LeaveApplicationForm
 */
public class LeaveApplicationForm extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public LeaveApplicationForm() {
		super();
		// TODO Auto-generated constructor stub
	}
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String methodName = request.getParameter("methodName");
		switch(methodName){
		case "submitFunction":{
			String oneDayLeave = request.getParameter("oneDayLeave");
			String halfDayOrFullDayLeave = request.getParameter("halfDayOrFullDayLeave");
			String daysGoingToTakeLeave = request.getParameter("daysGoingToTakeLeave");
			String leaveType = request.getParameter("leaveType");
			String startDate = request.getParameter("startDate");
			String endDate = request.getParameter("endDate");
			String leaveDays = request.getParameter("leaveDays"); 
			Date formattedStartDate = new Date(startDate);
			Date formattedEndDate = new Date(endDate);
			double leaveDayMultiplier;
			if(halfDayOrFullDayLeave.equals("halfDayLeave")){
				leaveDayMultiplier = 0.5;
			}
			//to format the date as per db saving
			System.out.println(new SimpleDateFormat("MM/dd/yyyy").format(formattedStartDate));
			System.out.println(new SimpleDateFormat("yyyy/MM/dd").format(formattedStartDate));
			System.out.println(startDate);
			response.addHeader("startDate", new SimpleDateFormat("MM/dd/yyyy").format(formattedStartDate));
			response.addHeader("endDate", new SimpleDateFormat("MM/dd/yyyy").format(formattedEndDate));
		}
		case "leaveDetailsOfEmployeesToLL":{/*
			List<Map<String, String>> leaveDetailsList = new LinkedList<Map<String, String>>();
			Map<String, String> dataMap;
			dataMap = new HashMap<String, String>(); 
			dataMap.put("employeeId", "674");
			dataMap.put("leaveAppliedFrom","02/03/2017");
			dataMap.put("leaveAppliedFrom","03/03/2017");
			leaveDetailsList.add(dataMap);
			dataMap = new HashMap<String, String>();
			dataMap.put("employeeId", "675");
			dataMap.put("leaveAppliedFrom","04/03/2017");
			dataMap.put("leaveAppliedFrom","05/03/2017");
			leaveDetailsList.add(dataMap);
			JSONObject obj = new JSONObject();
			try {
				obj.put("leaveDetailList", leaveDetailsList);
				response.addHeader("leaveDetails", obj.toString());
			} catch (JSONException e) {
				e.printStackTrace();
			}
		*/}
		case "employeeDetails":{
			// to get the employee details based on the employee id i.e., name llname pmoname casual leave taken sick leave taken and leave left
			response.addHeader("casualLeaveTaken", "0");
			response.addHeader("sickLeaveTaken", "0");
			response.addHeader("casualLeaveLeft", "12");
			response.addHeader("sickLeaveLeft", "6");
		}
	}
	String employeeId=request.getParameter("employeeId");
	String name=request.getParameter("name");
	response.addHeader("employeeId", employeeId);
	response.addHeader("name", name);
}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}
}