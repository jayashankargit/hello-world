$(document).ready(function(){
	$('#submit').click(function(){
		$.ajax({
			url:'ServletDemo1',
			data:{name:'abc'},
			type:'get',
			cache:false,
			success:function(data,status,xhr){
				var name1=xhr.getResponseHeader('name');
				alert(name1);
			},
			error:function(){
				alert('error');
			}
		});
	});
});