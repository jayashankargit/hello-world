var app=angular.module('myApp', []);
app.controller('login', function($scope) {
	$scope.isVisible=true;
	$scope.isRegisterVisible=false;
	$scope.forgetShow = true;
	$scope.isForgetVisible = false;
	$scope.loginFunction = function(){
		var mailId=$scope.mailId;
		var password=$scope.password;
		if(mailId!=null&&mailId!=''){
			if(password!=null&&password!=''){
				$.ajax({
					url:'LeaveApplicationLoginForm',
					data:{mailId:mailId,password:password,methodName:'loginFunction'},
					type:'post',
					cache:false,
					success:function(data,status,response){
						//to get the value, response as response from java
						var employeeId=response.getResponseHeader("employeeId");
						if(employeeId!=''){
							window.location="http://localhost:8080/learning/projectShiv.html?emp_id="+employeeId;
						}
					},
					error:function(){

					}
				});
			} else {
				alert('password is empty');
			}
		} else {
			alert('login_id and password is empty');
		}
	}
	$scope.divRegisterFunction = function(){
		$scope.isVisible=false;
		$scope.isRegisterVisible=true;
	}
	$scope.registerFunction = function(){
		var password=$scope.register_password;
		var reEnterPassword=$scope.register_re_enter_password;
		var mailId=$scope.mailId;
		if(mailId!=undefined){
			if(password!=undefined&&reEnterPassword!=undefined&&password===reEnterPassword){
				$.ajax({
					url:'LeaveApplicationLoginForm',
					data:{mailId:mailId,password:password,methodName:'registerFunction'},
					type:'post',
					cache:false,
					success:function(data,status,response){
						//to get the value, response as response from java
						console.log(response.getResponseHeader('mailIdResponse'));
						console.log(response.getResponseHeader('passwordResponse'));
					},
					error:function(){

					}
				});
			} else {

			}
		} else {
			alert('Please enter appropriate mailId');
		}
	}
	$scope.divLoginFunction = function(){
		$scope.isVisible=true;
		$scope.isRegisterVisible=false;
	}
	$scope.forgetVisibility = function(){
		if($scope.mailId != undefined && $scope.mailId != ''){
			$scope.forgetShow = true;
		} else {
			$scope.forgetShow = false;
		}
	};
	var randomPasswordGenerated='';
	$scope.forgetPassword = function(){
		if($scope.mailId!=undefined&&$scope.mailId!=''){
		$scope.isVisible=false;
		$scope.isForgetVisible = true;
		$.ajax({
			url:'LeaveApplicationLoginForm',
			data:{mailId:$scope.mailId,methodName:'mailIdCheck'},
			type:'post',
			cache:false,
			success:function(data,status,response){
				var mailIdResponseFlag=response.getResponseHeader('mailIdResponseFlag')
				if(mailIdResponseFlag){
				randomPasswordGenerated = response.getResponseHeader('randomPassword');
				$.ajax({
					url:'LeaveApplicationLoginForm',
					data:{mailId:$scope.mailId,methodName:'forgetPassword'},
					type:'post',
					cache:false,
					success:function(data,status,response){
						alert('success recovery password is send to your mail id:'+$scope.mailId);
						randomPasswordGenerated = response.getResponseHeader('randomPassword');
						//to get the value, response as response from java
					},
					error:function(){

					}
				});
			} else{
				alert('mail id is wrong, Please enter appropriate mail id');
			}
				//to get the value, response as response from java
			},
			error:function(){

			}
		});
	} else {
		alert('Enter proper mail id');
	}
	};
	$scope.forgetPasswordSubmitAction=function(){
		if($scope.forget_password == $scope.forget_re_enter_password && $scope.forget_re_enter_password != undefined){
			$.ajax({
				url:'LeaveApplicationLoginForm',
				data:{mailId:$scope.mailId,password:$scope.forget_password,methodName:'forgetSubmitFunction'},
				type:'post',
				cache:false,
				success:function(data,status,response){
					alert('forget password action successfully password saved');
					var employeeId=response.getResponseHeader("employeeId");
					if(employeeId!=''){
						window.location="http://localhost:8080/learning/projectShiv.html?emp_id="+employeeId;
					}
					//to get the value, response as response from java
				},
				error:function(){

				}
			});
		}
	};
	$scope.passwordRecoveryCheck=function(){
		if($scope.recovery_password!=randomPasswordGenerated){
			alert('recovery password is wrong please check your mail');
		}
	};
	$scope.forgetPasswordAction=function(){
		$scope.forgetPassword();
		$scope.recovery_password='';
		$scope.forget_password='';
		$scope.forget_re_enter_password='';
	};
});