var empId=window.location.search.split('?')[1].split('=')[1];
var app=angular.module('myApp', []);
app.controller('namesCtrl', function($scope) {
	$scope.employeeId=empId;
	employeeDetails();
	$scope.openCity=function(evt, cityName) {
	    var i, tabcontent, tablinks;
	    tabcontent = document.getElementsByClassName("tabcontent");
	    for (i = 0; i < tabcontent.length; i++) {
	        tabcontent[i].style.display = "none";
	    }
	    tablinks = document.getElementsByClassName("tablinks");
	    for (i = 0; i < tablinks.length; i++) {
	        tablinks[i].className = tablinks[i].className.replace(" active", "");
	    }
	    document.getElementById(cityName).style.display = "block";
	    evt.currentTarget.className += " active";
	}
	function employeeDetails(){
		//to get the employee records from db and leave left for the employee
		$scope.employeeName='Jaya Shankar L M S';
		$scope.designation='Trainee Engineer';
		$scope.llName='Krishna Muthusamy';
		$scope.pmoName='Manickaraja';
		$scope.casualLeaveLeft=12;
		$scope.sickLeaveLeft=6;
	}
	$scope.myFunction=function(endDate){
		if(endDate!=undefined){
			alert(JSON.stringify(endDate)+"cghhgcgh");
		}
	};
	$scope.employeeFocusOutFunction = function(){
		//to do a call to java to fetch datas from db
		$.ajax({
			url:'LeaveApplicationForm',
			data:{employeeId:$scope.employeeId,name:'abc'},
			type:'get',
			cache:false,
			success:function(data,status,xhr){
				var employeeId=xhr.getResponseHeader('employeeId');
				var name=xhr.getResponseHeader('name');
				console.log(employeeId);
				console.log(name);
			},
			error:function(){
				alert('error');
			}
		});
	};
	$scope.submitFunction = function(){
		var oneDayLeave;
		var halfDay;
//		console.log($scope.oneDayLeave);
//		if($scope.oneDayLeave==undefined){
//		oneDayLeave=0;
//		} else {
//		oneDayLeave=1;
//		}
//		if($scope.halfDay==undefined){
//		halfDay=0;
//		} else {
//		halfDay=1;
//		}
		//to send a mail to ll
		$.ajax({
			url:'LeaveApplicationForm',
			data:{name:'abc',
				methodName:'submitFunction',
				oneDayLeave:oneDayLeave,
				halfDay:halfDay,
				leaveType:$scope.item,
				startDate:$scope.startDate,
				endDate:$scope.endDate,
				leaveDays:$scope.leaveDays
			},
			type:'get',
			cache:false,
			success:function(data,status,response){
				var name1=response.getResponseHeader('name');
				$scope.names=[{'LeaveAppliedFrom':response.getResponseHeader('startDate'),'LeaveAppliedTo':response.getResponseHeader('endDate'),'Status':'pending'}];
			},
			error:function(){
				alert('error');
//				window.location = "http://localhost:8080/CPNYCJK/cjkweb";
			}
		});
//		$scope.names=[{'LeaveAppliedFrom':JSON.stringify($scope.startDate),'LeaveAppliedTo':JSON.stringify($scope.endDate),'Status':'pending'}];
	};
	/**
	 * to calculate leave days
	 * to do minus the leave days.
	 */
	$scope.leaveDayCalculationFunction = function(){
		if($scope.startDate !== undefined && $scope.startDate !== null
				&& $scope.endDate !== undefined && $scope.endDate !== null){
			var x=new Date();
			x=$scope.startDate;
			y=x.getDay();
			var dayCounter=y;
			var startDateValues = (JSON.stringify($scope.startDate)).split('-');
			var endDateValues = (JSON.stringify($scope.endDate)).split('-');
			var selectedEndYear = parseInt((!endDateValues[0])?'':endDateValues[0].replace('"',''));
			var selectedEndMonth = parseInt(endDateValues[1]);
			var selectedEndDate = parseInt(endDateValues[2]);
			var selectedStartYear = parseInt((!startDateValues[0])?'':startDateValues[0].replace('"',''));
			var selectedStartMonth = parseInt(startDateValues[1]);
			var selectedStartDate = parseInt(startDateValues[2]);
			var calculatedYearValue = selectedEndYear - selectedStartYear;
			var incrementer;
			var calculatedDateValue;
			var calculatedMonthValue;
			var addedDays = 0;
			var addedDateValue = 0;
			var reduceLeave=0;
			if(calculatedYearValue != 0 && !isNaN(calculatedYearValue)){
				addedMonthValue = (calculatedYearValue*12);
				calculatedMonthValue = (selectedEndMonth+addedMonthValue)-selectedStartMonth;
			} else{
				calculatedMonthValue = selectedEndMonth - selectedStartMonth;
			}
			for(incrementer = 0; incrementer < calculatedMonthValue; incrementer++){
				if(calculatedMonthValue != 0){
					if(selectedStartMonth <= 6){
						if((selectedStartMonth % 2 == 0)&&!(selectedStartMonth == 2)){
							addedDays = addedDays + 30;
						} else if(selectedStartMonth == 2){
							if(selectedStartYear % 4 == 0 && selectedStartYear % 100 == 0 && selectedStartYear % 400 == 0){
								addedDays = addedDays + 29;
							} else {
								addedDays = addedDays + 28;
							}
						} else {
							addedDays = addedDays + 31;
						}
					} else {
						if(selectedStartMonth % 2 == 0 || selectedStartMonth == 7){
							addedDays = addedDays + 31;
						} else {
							addedDays = addedDays + 30;
						}
					}
				} else {
					calculatedDateValue = selectedEndDate - selectedStartDate;	
				}
				addedDateValue = addedDays;
				if(selectedStartMonth == 12){
					selectedStartMonth = 1;
				} else {
					selectedStartMonth++;
				}
			}
			calculatedDateValue=(selectedEndDate+addedDateValue) - selectedStartDate+1;
		}
		for(counter=0;counter<calculatedDateValue;counter++){
			if(dayCounter>6){
				dayCounter=0;
			}
			if(dayCounter==0||dayCounter==6){
				reduceLeave++;
			}
			dayCounter++;
		}
		$scope.calculatedDateValue=calculatedDateValue-reduceLeave;
	};
	$scope.myData=[{name:'jay', age:21},
	               {name:'hari', age:21}
	];
	$scope.gridOptions={data:'myData'};
});