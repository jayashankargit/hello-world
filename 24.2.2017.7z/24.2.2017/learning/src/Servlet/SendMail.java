package Servlet;

import java.util.Properties;

import org.apache.catalina.Session;
import org.apache.catalina.tribes.tipis.AbstractReplicatedMap.MapMessage;

import sun.rmi.transport.Transport;

import com.sun.xml.internal.messaging.saaj.packaging.mime.MessagingException;
import com.sun.xml.internal.messaging.saaj.packaging.mime.internet.MimeBodyPart;

public class SendMail {
	public static void main(String [] args) {    
	      // Recipient's email ID needs to be mentioned.
	      String to = "abcd@gmail.com";

	      // Sender's email ID needs to be mentioned
	      String from = "web@gmail.com";

	      // Assuming you are sending email from localhost
	      String host = "localhost";

	      // Get system properties
	      Properties properties = System.getProperties();

	      // Setup mail server
	      properties.setProperty("mail.smtp.host", host);

	      // Get the default Session object.
	      Session session;// = Session.getDefaultInstance(properties);

	      try {
	    	  MimeBodyPart messageBodyPart=new MimeBodyPart();
	         // Create a default MimeMessage object.
	         MapMessage message = new MapMessage();

	         // Set From: header field of the header.
	         message.setFrom(new InternetAddress(from));

	         // Set To: header field of the header.
	         message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));

	         // Set Subject: header field
	         ((Object) message).setSubject("This is the Subject Line!");

	         // Now set the actual message
	         ((Object) message).setText("This is actual message");

	         // Send message
	         Transport.send(message);
	         System.out.println("Sent message successfully....");
	      }catch (MessagingException mex) {
	         mex.printStackTrace();
	      }
	   }
}