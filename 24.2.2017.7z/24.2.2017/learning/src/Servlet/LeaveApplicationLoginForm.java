package Servlet;

import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class LeaveApplicationLoginForm
 */
public class LeaveApplicationLoginForm extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public LeaveApplicationLoginForm() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String methodName=request.getParameter("methodName");
		switch(methodName){
		case "loginFunction":
			String mailId=request.getParameter("mailId");
			String password=request.getParameter("password");
			if(mailId.equals("jay")&&password.equals("jay")){
				response.addHeader("employeeId", "674");
			} else {
				response.addHeader("employeeId", "");
			}
			System.out.println(mailId+password);
			break;
		case "registerFunction":
			String registerMailId=request.getParameter("mailId")+"response";
			String registerPassword=request.getParameter("password")+"response";
			response.addHeader("mailIdResponse", registerMailId);
			response.addHeader("passwordResponse", registerPassword);
			break;
		case "forgetPassword":
			PasswordGenerator passwordObject;
			String randomPassword = null;
			try {
				passwordObject = new PasswordGenerator();
				randomPassword = passwordObject.getRandomPassword();
				response.addHeader("randomPassword",randomPassword);
			} catch (NoSuchAlgorithmException e) {
				e.printStackTrace();
			} catch (NoSuchProviderException e) {
				e.printStackTrace();
			}
			System.out.println(randomPassword);
			break;
		case "mailIdCheck":
			//to verify whether there is appropriate mail id in the db and get response from the db
			String mailIdCheck=request.getParameter("mailId");
			if(mailIdCheck.equals("jay")){
				response.addHeader("mailIdResponseFlag", "true");
			} else{
				response.addHeader("mailIdResponseFlag", "false");
			}
			break;
		case "forgetSubmitFunction":
			String forgetPassword = request.getParameter("password");
			String mailIdRecoverySave = request.getParameter("mailId");
			System.out.println(forgetPassword);
			//to update the password in the db and retreive the details of the employee
			response.addHeader("employeeId", "674");
			break;
		default:
			break;
		}
		// TODO search the mail id and password for the login mail id and give the response back
		//		response.addHeader(arg0, arg1);
	}

}
