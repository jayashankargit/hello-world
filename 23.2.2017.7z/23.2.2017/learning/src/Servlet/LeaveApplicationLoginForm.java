package Servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class LeaveApplicationLoginForm
 */
public class LeaveApplicationLoginForm extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public LeaveApplicationLoginForm() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String methodName=request.getParameter("methodName");
		switch(methodName){
		case "loginFunction":
			String mailId=request.getParameter("mailId");
			String password=request.getParameter("password");
			if(mailId.equals("jay")&&password.equals("jay")){
				response.addHeader("employeeId", "674");
			} else {
				response.addHeader("employeeId", "");
			}
			System.out.println(mailId+password);
			break;
		case "registerFunction":
			String registerMailId=request.getParameter("mailId")+"response";
			String registerPassword=request.getParameter("password")+"response";
			response.addHeader("mailIdResponse", registerMailId);
			response.addHeader("passwordResponse", registerPassword);
			break;
		default:
			break;
		}
		// TODO search the mail id and password for the login mail id and give the response back
		//		response.addHeader(arg0, arg1);
	}

}
